﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ControllerScript : MonoBehaviour
{
    public Button genButton;
    public Button inputButton;
    public Button clearButton;

    public InputField nameInput;

    public Text[] rollText;
    public Text[] totalText;

    public Text characterText;
    public Text errorText;

    private int[,] rollArray = new int[6, 6];
    private int[] totalArray = new int[6];
    // Start is called before the first frame update
    void Start()
    {
        characterText.text = "";
        errorText.text = "";
        nameInput.text = "";
        genButton.interactable = false;
        //sets up the board. Changes texts to false, and doesn't allow you to use the gen/totals button
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnInputButtonClick()
    {
        string inputString = nameInput.text; //the variable input string is set to what is inputed into the field

        if(inputString == "")
        {
            errorText.text = "ERROR! Please enter a name."; //gives an error to enter a name
            nameInput.text = "";
        }
        else if (inputString.Length > 16) //if the inputString is over 16 characters
        {
            errorText.text = "ERROR! Name is more than 16 characters!"; //gives an error about being more than 16 characters
            nameInput.text = "";
        }
        else //as long as it follows the guidelines
        {
            errorText.text = "";
            genButton.interactable = true;
            inputButton.interactable = false; //makes it so the user can't use the input button as long as the board isn't cleared
            nameInput.text = "";
            characterText.text = inputString; 
        }
    }
    public void OnGenButtonClick()
    {
        for(int r = 0; r < rollArray.GetLength(0); r++) //goes for as many rows are in the rollArray. In this case, 6
        {
            for(int c = 0; c < rollArray.GetLength(1); c++) //goes for as many columns there are in the rollArray. In this case, 6
            {
                rollArray[r, c] = Random.Range(1, 21); //assigns that value of the rollArray a random number
                totalArray[r] += rollArray[r, c]; //adds this number to the totalArray, as each value in the totalArray element corrosponds with the same column
            }
        }
        for(int i = 0; i < rollText.Length; i++) //goes for as long as the rollText.Length exists; within the controller object, we have set this to 6 seperate texts.
        {
            rollText[i].text = PrintRoll(i) + PrintTotal(i); //calls the printroll/print total functions, passing the i (index value) variable
        }
        for (int i = 0; i < totalText.Length; i++)
        {
            totalText[i].text = CreateTotals(i).ToString(); //calls the createTotals function, passing the i (index value) variable. then assisgns it to the totalText array in corrospondance to the i variable
        }
    }
    public void OnClearButtonClick()
    {
        ClearRolls(); //calls the clearRolls function
        ClearTotals(); //calls the clearTotals function
        characterText.text = ""; //clears out the characterText
        genButton.interactable = false; //makes it so you can't generate rolls
        inputButton.interactable = true; //makes it so you can now input names again
    }

    public void OnQuitButtonClick()
    {
        Application.Quit();
    }
    private string PrintRoll(int rollIndex) //passes the roll index
    {
        string toReturn = ""; //creates an empty string

        for(int r = 0; r < 6; r++) //iterates a loop 6 times. you can do rollArray.Length(0) here if you wish, it'll give the same result
        {
            toReturn += rollArray[r, rollIndex] + "\n"; //adds 
        }
        return (toReturn);
    }
    private string PrintTotal(int rollIndex)
    {
        int toReturn = 0;
        int total = 0;
        for (int c = 0; c < rollArray.GetLength(0); c++)
        {
            toReturn += rollArray[c, rollIndex];
            total += rollArray[c, rollIndex];
        }
        totalArray[rollIndex] = total;
        return (toReturn.ToString() + "\n");
    }
    private int CreateTotals(int statIndex)
    {
        int lowestValue = 100;
        int highestValue = 0;
        int total = 0;


        for (int i = 0; i < rollArray.GetLength(1); i++) //goes for as many rows are in the rollArray. In this case, 6
        {
            int arrayNumber = rollArray[i, statIndex];
            lowestValue = CompareSmaller(arrayNumber, lowestValue);
            highestValue = CompareLarger(arrayNumber, highestValue);
        }

        total = totalArray[statIndex];
        total = total - lowestValue;
        total = total - highestValue;
        total = total / 4;
        return (total);
    }
    private int CompareLarger (int one, int two)
    {
        int largernumber = 0;
        if(one > two)
        {
            largernumber = one;
            return (largernumber);
        }
        else if (two > one)
        {
            largernumber = two;
            return (largernumber);
        }
        else
        {
            largernumber = one;
            return (largernumber);
        }
    }
    private int CompareSmaller (int one, int two)
    {
        int smallernumber = 0;
        if(one < two)
        {
            smallernumber = one;
            return (smallernumber);
        }
        else if(two < one)
        {
            smallernumber = two;
            return (smallernumber);
        }
        else
        {
            smallernumber = one;
            return (smallernumber);
        }
    }
    private void ClearRolls()
    {
        for(int r = 0; r < rollArray.GetLength(0); r++)
        {
            for(int c = 0; c < rollArray.GetLength(1); c++)
            {
                rollArray[r, c] = 0; //clears the array
            }
        }
    }
    private void ClearTotals()
    {
        for(int i = 0; i < totalArray.Length; i++)
        {
            totalArray[i] = 0; //clears
            rollText[i].text = "";
            totalText[i].text = "";
        }
    }
}
